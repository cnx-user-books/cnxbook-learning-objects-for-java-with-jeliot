// Learning Object Control04
//    do-while loops
public class Control04 {
    public static void main(/*String[] args*/) {
        int input;
        do {
             input = Input.nextInt();
        } while (input <= 0);
        System.out.println(input);
    }
}
